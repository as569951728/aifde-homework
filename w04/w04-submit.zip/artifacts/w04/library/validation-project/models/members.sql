select * from raw_members
